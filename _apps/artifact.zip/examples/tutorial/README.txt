The main example is pingflood. 

1. Go to directory "pingflood"
2. Run the following command to compile P programs.
  build.bat
3. Run the following command to run verification
  run.bat
4. back to directory "tutorial" and run the following command:
  process-results.bat


NOTE: For the example in the folder "choice" and "nonresponsive". Play around with them if you like. 
The generated .log or .out

1) if a filename contains "pat": then it results from PAT;
2) if a filename contains "pati": then it results from PAT+I;
3) if a filename contains "ptester": then it results from PTester.

Note: the running time of PTester should be the sum of running time in all PTester output. 